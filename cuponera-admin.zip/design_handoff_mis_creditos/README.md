# Handoff: «Mis Créditos» — créditos como moneda administrable

## Overview
Rediseño de la pantalla **Mi Cuenta** del panel del **socio alojamiento**. El concepto cambia de fondo:
los **créditos** dejan de ser «un descuento fijo» y pasan a ser una **moneda que el socio administra**, con
tres usos posibles:

- **A · Bajar el abono** — canjea créditos por *packs de descuento* que restan pesos del plan mensual.
- **B · Enviar créditos** — le pasa saldo a un huésped o amigo (link, QR o envío directo).
- **C · Canjear beneficios para sí mismo** — usa sus créditos en ofertas de terceros (como un turista) y arma su propia cuponera.

> **Importante (modelo económico):** un crédito **no** vale un monto fijo de descuento. El valor lo define
> cada *pack*. El socio **compra un pack y lo agrega a su cuponera**, exactamente la misma mecánica que un
> turista al activar una oferta. Esto reusa UI y lógica que ya existen.

## About the Design Files
Los archivos de este bundle son **referencias de diseño hechas en HTML/React** (prototipos que muestran
el look & feel y el comportamiento buscado), **no código de producción para copiar tal cual**. La tarea es
**recrear estos diseños dentro del codebase real** (`gesell-ar`, React + Tailwind, design system «Aire»),
usando sus componentes y patrones existentes — sobre todo `OfertaCardAire` y los tokens de color del panel.

**Este README es la fuente de verdad.** Donde el HTML difiera de lo descripto acá (p. ej. la estructura
vieja de la ficha o el nombre «gesell.ar»), mandan las indicaciones de este README.

## Fidelity
**Alta fidelidad.** Colores, tipografía, jerarquía y estructura son finales. Recrear pixel-cerca usando
los componentes reales del codebase, no inventar estilos nuevos.

---

## Screen: «Mi Cuenta» (socio alojamiento)

Orden vertical de la pantalla (todo sobre fondo claro `#f8fafc`, contenedores blancos limpios):

1. **Header** — `H1` "Mi Cuenta".
2. **Fila superior en 2 columnas:** `Mis créditos` (izq.) + `Plan activo` (der.).
3. **Bajá tu abono con créditos** — bloque con las 3 mini-fichas de packs.
4. **Dos acciones secundarias en 2 columnas:** `Enviar créditos a un huésped o amigo` + `Canjear beneficios para vos`.
5. **Movimientos** — **ancho completo** (ya no comparte fila con el plan).

### 1. Bloque «Mis créditos» (columna izquierda de la fila superior)
- Card blanca, `border 1px #e2e8f0`, `radius 16`, `padding 20`.
- Moneda dorada grande + saldo (`font-size 32, weight 800, #0f172a`).
- Chip verde `+N este mes` (`#10b981` sobre `#ecfdf5`).
- Botones: **Enviar** (secundario, borde gris) y **Comprar** (primario `#475be1`).

### 2. Card «Plan activo» (columna derecha) — versión clara
- Card blanca (NO oscura), misma familia visual que el resto.
- Ícono `zap` en chip `#eef0fd`/`#475be1`. Etiqueta "PLAN ACTIVO" + "PLUS".
- **Precio: mensual grande, anual chico en gris** (igual que el pricing tab):
  - `$18.300` grande + `/mes` gris · debajo `$220.000 /año` en `#94a3b8`.
  - (18.300 = 220.000 ÷ 12, redondeado. Confirmar el número real con `cobros.js`.)
- Pie: "Próximo cobro · 1 de julio" + link "Gestionar →".

### 3. Bloque «Bajá tu abono con créditos»
- Card blanca contenedora, título `16/800` + bajada gris "Agregalos a tu cuponera y pagá con créditos".
- Dentro, **grid de 3 mini-fichas** (`repeat(3,1fr)`, gap 14).

#### Mini-ficha de PACK — DEBE replicar la estructura de `OfertaCardAire` (home)
Misma anatomía que la ficha de oferta del home, con la **"cajita de precios"** de dos filas:

- **Imagen/cabezal** del card (puede ser un tile de marca con el descuento, o imagen estándar de la ficha).
- **Badge** (esquina, estilo idéntico al del home): **`-2k`**, **`-5k`**, **`-10k`** — *sin el signo `$`*.
- Nombre del comercio → **"Cuponera"** (NO «gesell.ar»). Rubro/bajada: "Descuento de abono".
- **Cajita de precios (igual al home):**
  - Fila 1 — **"Ahorro"** *(en este caso particular SIN la palabra "estimado")* → monto en verde, ej. `$2.000`.
  - divisor
  - Fila 2 — **"Lo activás con"** → 🪙 `N créditos`.
- CTA: botón "Agregar" (a la cuponera), primario `#475be1`.

Los tres packs:

| Pack | Badge | Ahorro | Lo activás con |
|------|-------|--------|----------------|
| 1 | `-2k`  | $2.000  | 🪙 8 créditos  |
| 2 | `-5k`  | $5.000  | 🪙 18 créditos |
| 3 | `-10k` | $10.000 | 🪙 32 créditos |

> Costos en créditos a confirmar/parametrizar. La idea: tasa mejor al comprar packs más grandes.
> Base sugerida: crédito ≈ $500 de "poder de canje" (8 cr → $2.000). El precio de **compra** de un
> crédito sigue siendo `CREDITO_PRECIO` ($2.000 + IVA) según `cobros.js`; son cosas distintas
> (comprar vs. canjear) y NO hay que mostrar equivalencia en $ del crédito.

### 4. Acciones secundarias (2 columnas)
Cards blancas con ícono en chip de color, título, descripción y pie.

- **"Enviar créditos a un huésped o amigo"** (ícono `send`, verde `#10b981`)
  - Subtítulo ajustado: "Pasale saldo con un link o QR. Lo recibe al instante en su cuenta."
  - Pie con los 3 métodos: **Link · QR · Directo**.
  - *(Mecánica real: genera link/QR que acredita saldo a favor en la cuenta de quien lo recibe;
    o envío directo por email/teléfono.)*
- **"Canjear beneficios para vos"** (ícono `gift`, ámbar `#f59e0b`)
  - "Usá tus créditos en ofertas de Cuponera como cualquier usuario y armá tu propia cuponera."
  - Pie: "Explorar el marketplace →".

### 5. «Movimientos» — ancho completo
- Renombrado desde "Historial".
- **Libro bimoneda** (créditos virtuales + pesos reales) en una sola lista.
- **Filtro por moneda**: pills `Todo · Créditos · Pesos`.
- Cada fila: ícono según tipo + título + fecha + monto a la derecha.
  - **Ingreso de créditos** (`+🪙N`, verde) — ej. "Huésped compró cuponera de {comercio}".
  - **Egreso de créditos** (`−🪙N`, rojo/neutro) — canje de pack, envío a otro usuario.
  - **Pago en $** (`−$X`, neutro) — "Cobro plan PLUS · {mes}".
  - **Compra de créditos** — fila bimoneda: `+🪙20` y `−$12.100`.

---

## Mini-resumen para el tab «Resumen»
Reemplaza el viejo cuadro «Fórmula de ahorro mensual». Banda compacta con: saldo de créditos +
`+N este mes` + 3 accesos rápidos (Bajar abono · Enviar · Canjear) que linkean a esta pantalla.
*(En el HTML quedó como hero oscuro; si se prefiere consistencia con el resto del panel claro,
adaptarlo a fondo claro.)*

---

## Design Tokens (del panel real)
| Rol | Valor |
|-----|-------|
| Primario | `#475be1` · hover `#3347c8` · soft `#eef0fd` |
| Tinta / texto | `#0f172a` · sec. `#475569` · mute `#94a3b8` |
| Líneas | `#e2e8f0` · fondo `#f8fafc` · card `#ffffff` |
| Éxito (ahorro/ingreso) | `#10b981` · soft `#ecfdf5` |
| Acento moneda | dorado `#f9c829`→`#f0a211` (gradiente) |
| Alerta/egreso | `#ef4444` |
| Radius | cards 16 · fichas 18 · chips 11–12 · pills 999 |
| Tipografía | Inter — 800 títulos, 600/700 cuerpo |

## Assets
- **Moneda dorada:** ⚠️ El asset `public/cuponera-coin.svg` está **roto**: usa clases CSS `st0/st1/st2`
  que quedaron **sin definir** (export de Illustrator), así que los círculos base caen a **negro** y
  tapan el oro. Se ve oscura en **toda la app** (el `CoinSVG` real apunta al mismo archivo).
  **Acción para Code:** regenerar el SVG con los `fill` embebidos (o pegarle el bloque `<style>` con los
  fills dorados). En las referencias HTML usé una moneda dorada inline como reemplazo provisorio.
- **Íconos:** estilo lucide (stroke 2, round). Usar la librería de íconos que ya tenga el codebase.

## Files (referencias en este bundle)
- `Mis Créditos.html` — tablero con las 3 direcciones exploradas + el mini-resumen. La dirección
  elegida es **B (packs al frente)** con los ajustes de este README aplicados encima.
- `components/creditos-kit.jsx` — primitivas (moneda, ficha de pack, plan, movimientos, íconos, filtro).
- `components/creditos-variants.jsx` — las 3 variantes de pantalla.

## Componentes del codebase a reutilizar (no reinventar)
- `OfertaCardAire` (en `src/views/HomeView.jsx`) — base de la mini-ficha de pack.
- Lógica de tokens/créditos: `src/lib/gamificacion.js`, `src/lib/cobros.js`.
- Flujo de "agregar a la cuponera" ya existente para activar el pack de descuento.
