// ════════════════════════════════════════════════════════════
//  creditos-variants.jsx — «Mis créditos» (dirección B refinada)
// ════════════════════════════════════════════════════════════
const { P, PD, PS, INK, INK2, MUTED, LINE, BG, CARD, NAVY, GREEN, GREENS, YELLOW, RED, FONT, fmt$ } = CK;

const SALDO = 26, GANADOS_MES = 8;

// Wrapper que simula el área "main" del panel
function Screen({ children, pad = 24 }) {
  return <div style={{ background:BG, padding:pad, fontFamily:FONT, boxSizing:'border-box', width:'100%', minHeight:'100%' }}>{children}</div>;
}
function H1() {
  return <h1 style={{ fontFamily:FONT, fontSize:22, fontWeight:800, color:INK, margin:'0 0 18px' }}>Mi Cuenta</h1>;
}

// ─── Card «Mis créditos» (clara, top-izquierda) ───────────────
function MisCreditosCard() {
  const Btn = ({ primary, icon, label }) => (
    <button style={{ flex:1, display:'inline-flex', alignItems:'center', justifyContent:'center', gap:6, borderRadius:11, padding:'10px 0', fontSize:13, fontWeight:700, cursor:'pointer', fontFamily:FONT,
      background: primary?P:'#fff', color: primary?'#fff':INK, border: primary?'none':`1px solid ${LINE}` }}>
      {icon} {label}
    </button>
  );
  return (
    <div style={{ background:CARD, border:`1px solid ${LINE}`, borderRadius:16, padding:20, fontFamily:FONT, height:'100%', boxSizing:'border-box', display:'flex', flexDirection:'column' }}>
      <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:14 }}>
        <div style={{ width:58, height:58, borderRadius:16, background:`${YELLOW}14`, border:`1px solid ${YELLOW}33`, display:'grid', placeItems:'center', flexShrink:0 }}><Coin size={34}/></div>
        <div>
          <div style={{ fontSize:11, color:MUTED, fontWeight:700, textTransform:'uppercase', letterSpacing:'0.06em' }}>Mis créditos</div>
          <div style={{ display:'flex', alignItems:'baseline', gap:8 }}>
            <span style={{ fontSize:38, fontWeight:800, color:INK, letterSpacing:'-0.025em', lineHeight:1 }}>{SALDO}</span>
            <span style={{ fontSize:13, color:GREEN, fontWeight:700 }}>+{GANADOS_MES} este mes</span>
          </div>
        </div>
      </div>
      <div style={{ fontSize:12.5, color:INK2, lineHeight:1.45, marginBottom:16 }}>Ganás 1 crédito por cada recomendación a un comercio aliado que se convierte en compra.</div>
      <div style={{ marginTop:'auto', display:'flex', gap:8 }}>
        <Btn icon={<Ic.send s={15}/>} label="Enviar"/>
        <Btn primary icon={<Ic.plus s={15}/>} label="Comprar"/>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
//  VARIANTE B — refinada
// ════════════════════════════════════════════════════════════
function VarB() {
  return (
    <Screen>
      <H1/>
      <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

        {/* Top: Mis créditos | Plan activo (2 columnas) */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14, alignItems:'stretch' }}>
          <MisCreditosCard/>
          <PlanActivoLight/>
        </div>

        {/* Bajá tu abono — packs al frente */}
        <div style={{ background:CARD, border:`1px solid ${LINE}`, borderRadius:18, padding:20 }}>
          <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom:4, gap:12, flexWrap:'wrap' }}>
            <div style={{ fontSize:16, fontWeight:800, color:INK }}>Bajá tu abono con créditos</div>
            <span style={{ fontSize:12.5, color:MUTED, fontWeight:600 }}>Agregalos a tu cuponera y pagá con créditos</span>
          </div>
          <div style={{ fontSize:13, color:INK2, marginBottom:16 }}>Cada pack descuenta pesos de tu próximo abono. Misma mecánica que cualquier oferta.</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:14 }}>
            <PackFicha badge="-2k" off={2000} cred={8}/>
            <PackFicha badge="-5k" off={5000} cred={18} popular/>
            <PackFicha badge="-10k" off={10000} cred={32}/>
          </div>
        </div>

        {/* Otras 2 acciones */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
          <AccionCard icon={<Ic.send/>} tint={GREEN} title="Enviar créditos a un huésped o amigo"
            desc="Generá un link o QR para compartir, o envialos directo. Los recibe al instante como saldo a favor en su cuenta."
            foot={<span style={{ display:'inline-flex', alignItems:'center', gap:10, fontSize:12, fontWeight:700, color:INK2 }}><span style={{ display:'inline-flex', alignItems:'center', gap:4 }}><Ic.link s={13}/>Link</span><span style={{ display:'inline-flex', alignItems:'center', gap:4 }}><Ic.qr s={13}/>QR</span><span style={{ display:'inline-flex', alignItems:'center', gap:4 }}><Ic.send s={13}/>Directo</span></span>}/>
          <AccionCard icon={<Ic.gift/>} tint={YELLOW} title="Canjear beneficios para vos"
            desc="Usá tus créditos en ofertas de Cuponera como cualquier usuario y armá tu propia cuponera."
            foot={<span style={{ fontSize:12, fontWeight:700, color:INK2 }}>Explorar el marketplace →</span>}/>
        </div>

        {/* Movimientos — todo el ancho */}
        <Movimientos/>
      </div>
    </Screen>
  );
}

// ════════════════════════════════════════════════════════════
//  MINI-RESUMEN para el tab «Resumen» (reemplaza la Fórmula de ahorro)
// ════════════════════════════════════════════════════════════
function MiniResumen() {
  const Quick = ({ icon, tint, label }) => (
    <button style={{ display:'flex', alignItems:'center', gap:9, background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.12)', borderRadius:12, padding:'10px 14px', cursor:'pointer', fontFamily:FONT, textAlign:'left', flex:1, minWidth:0 }}>
      <span style={{ width:32, height:32, borderRadius:9, background:tint+'26', color:tint, display:'grid', placeItems:'center', flexShrink:0 }}>{icon}</span>
      <span style={{ fontSize:13, fontWeight:700, color:'#fff', whiteSpace:'nowrap' }}>{label}</span>
    </button>
  );
  return (
    <div style={{ position:'relative', overflow:'hidden', background:`linear-gradient(135deg, ${NAVY} 0%, #1b2440 60%, #20204a 100%)`, borderRadius:16, padding:22, fontFamily:FONT, color:'#fff' }}>
      <div style={{ position:'absolute', width:160, height:160, borderRadius:'50%', background:'rgba(125,161,255,0.14)', top:-70, right:-30 }}/>
      <div style={{ position:'relative', display:'flex', alignItems:'center', gap:24, flexWrap:'wrap' }}>
        <div style={{ flexShrink:0 }}>
          <div style={{ fontSize:11.5, fontWeight:800, letterSpacing:'0.07em', textTransform:'uppercase', color:'rgba(255,255,255,0.55)', marginBottom:8 }}>Mis créditos</div>
          <div style={{ display:'flex', alignItems:'flex-end', gap:10 }}>
            <Coin size={34}/>
            <span style={{ fontSize:40, fontWeight:800, lineHeight:0.9, letterSpacing:'-0.03em' }}>{SALDO}</span>
            <span style={{ background:'rgba(52,211,153,0.18)', color:'#34d399', borderRadius:999, padding:'4px 10px', fontSize:12, fontWeight:700, marginBottom:4 }}>+{GANADOS_MES} este mes</span>
          </div>
        </div>
        <div style={{ flex:1, minWidth:280, display:'flex', gap:10 }}>
          <Quick icon={<Ic.cupon s={16}/>} tint="#9db4ff" label="Bajar abono"/>
          <Quick icon={<Ic.send s={16}/>} tint="#34d399" label="Enviar"/>
          <Quick icon={<Ic.gift s={16}/>} tint="#FBD96C" label="Canjear"/>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { VarB, MisCreditosCard, MiniResumen });
