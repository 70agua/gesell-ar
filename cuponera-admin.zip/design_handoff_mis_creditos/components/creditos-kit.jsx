// ════════════════════════════════════════════════════════════
//  creditos-kit.jsx — primitivas compartidas para «Mis créditos»
//  Tokens reales de AdminNegocioView.jsx + ficha de OfertaCard.jsx
// ════════════════════════════════════════════════════════════
const P='#475be1', PD='#3347c8', PS='#eef0fd', INK='#0f172a', INK2='#475569',
      MUTED='#94a3b8', LINE='#e2e8f0', BG='#f8fafc', CARD='#ffffff', NAVY='#0f172a',
      GREEN='#10b981', GREENS='#ecfdf5', YELLOW='#f59e0b', RED='#ef4444';
const FONT = "'Inter', system-ui, sans-serif";
const fmt$ = n => '$' + Math.abs(n).toLocaleString('es-AR');

// ─── Moneda dorada inline (el asset cuponera-coin.svg viene roto a nivel app) ──
function Coin({ size = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" style={{ display:'inline-block', verticalAlign:'middle', flexShrink:0 }} aria-hidden="true">
      <defs>
        <linearGradient id="gck_rim" x1="6" y1="5" x2="34" y2="35" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#FBDB72"/><stop offset="0.55" stopColor="#F4A91C"/><stop offset="1" stopColor="#D87708"/>
        </linearGradient>
        <linearGradient id="gck_face" x1="9" y1="8" x2="31" y2="32" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#FFEEB0"/><stop offset="0.5" stopColor="#F9C829"/><stop offset="1" stopColor="#F0A211"/>
        </linearGradient>
      </defs>
      <circle cx="20" cy="20" r="19" fill="url(#gck_rim)"/>
      <circle cx="20" cy="20" r="14.5" fill="url(#gck_face)"/>
      <path d="M20 9 C20.6 16.5 23.5 19.4 31 20 C23.5 20.6 20.6 23.5 20 31 C19.4 23.5 16.5 20.6 9 20 C16.5 19.4 19.4 16.5 20 9 Z" fill="#E08A0B" opacity="0.5"/>
      <ellipse cx="14.5" cy="13.5" rx="5.5" ry="3.6" fill="#FFFFFF" opacity="0.4"/>
    </svg>
  );
}

// Saldo de créditos: moneda + número (sobre claro u oscuro)
function Credits({ n, size = 16, weight = 800, color = INK }) {
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:5 }}>
      <Coin size={size}/><span style={{ fontWeight:weight, color, fontSize:size, lineHeight:1 }}>{n}</span>
    </span>
  );
}

// ─── Marca gesell (cuadradito azul con g) ─────────────────────
function GLogo({ size = 40, radius = 11 }) {
  return (
    <div style={{ width:size, height:size, borderRadius:radius, background:`linear-gradient(135deg, ${P}, ${PD})`, display:'grid', placeItems:'center', flexShrink:0 }}>
      <span style={{ color:'#fff', fontFamily:FONT, fontWeight:800, fontSize:size*0.5, lineHeight:1 }}>g</span>
    </div>
  );
}

// ─── Íconos (lucide-like, stroke 2 round) ─────────────────────
const S = { fill:'none', stroke:'currentColor', strokeWidth:2, strokeLinecap:'round', strokeLinejoin:'round' };
const Ic = {
  cupon:  (p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><path d="M3 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2Z"/><path d="M15 5v14" strokeDasharray="2 2"/></svg>,
  send:   (p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>,
  gift:   (p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/><path d="M12 8C12 5 10.5 3 8.5 3S5 4.5 5 6.5 7 8 9 8M12 8c0-3 1.5-5 3.5-5S19 4.5 19 6.5 17 8 15 8"/></svg>,
  qr:     (p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3M21 14v.01M14 21h.01M21 21v-4M17 21h.01"/></svg>,
  link:   (p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.5-1.5"/></svg>,
  filter: (p)=><svg width={p?.s||16} height={p?.s||16} viewBox="0 0 24 24" {...S}><path d="M22 3H2l8 9.46V19l4 2v-8.54Z"/></svg>,
  chevR:  (p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><path d="m9 18 6-6-6-6"/></svg>,
  plus:   (p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><path d="M5 12h14M12 5v14"/></svg>,
  inflow: (p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><path d="M17 7 7 17M17 17H7V7"/></svg>,
  outflow:(p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><path d="M7 17 17 7M7 7h10v10"/></svg>,
  card:   (p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>,
  copy:   (p)=><svg width={p?.s||16} height={p?.s||16} viewBox="0 0 24 24" {...S}><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>,
  zap:    (p)=><svg width={p?.s||18} height={p?.s||18} viewBox="0 0 24 24" {...S}><path d="M13 2 3 14h9l-1 8 10-12h-9Z"/></svg>,
};

// ─── Mini-ficha de PACK de abono (misma estructura que OfertaCard del home) ──
// El socio la agrega a su cuponera y la paga con créditos.
// Estructura home: imagen+badge · proveedor · título · CTA · cajita (Ahorro / Lo activás con).
function PackFicha({ off, cred, popular, badge }) {
  return (
    <div style={{ background:CARD, border:`1px solid ${LINE}`, borderRadius:18, overflow:'hidden', display:'flex', flexDirection:'column', fontFamily:FONT }}>
      {/* "Imagen" = header de marca claro con el badge -Xk */}
      <div style={{ position:'relative', height:100, overflow:'hidden', background:`linear-gradient(135deg, ${PS} 0%, #e3e8ff 100%)` }}>
        <div style={{ position:'absolute', width:130, height:130, borderRadius:'50%', background:'rgba(71,91,225,0.10)', top:-46, right:-30 }}/>
        <div style={{ position:'absolute', width:80, height:80, borderRadius:'50%', background:'rgba(249,200,41,0.18)', bottom:-26, left:-12 }}/>
        {popular && <div style={{ position:'absolute', top:11, right:11, background:YELLOW, color:'#5a3d00', fontSize:10, fontWeight:800, padding:'4px 9px', borderRadius:7 }}>MÁS ELEGIDO</div>}
        <div style={{ position:'absolute', inset:0, display:'grid', placeItems:'center' }}>
          <div style={{ fontSize:46, fontWeight:800, letterSpacing:'-0.03em', lineHeight:1, color:P }}>{badge}</div>
        </div>
      </div>
      {/* cuerpo */}
      <div style={{ padding:'14px 16px 16px', display:'flex', flexDirection:'column', flex:1 }}>
        <div style={{ fontSize:13, color:MUTED, fontWeight:600, marginBottom:4 }}>Cuponera · Descuento de abono</div>
        <div style={{ fontSize:15, fontWeight:700, color:GREEN, lineHeight:1.3, marginBottom:10 }}>Bajá tu abono mensual</div>
        <button style={{ background:P, color:'#fff', border:'none', borderRadius:12, padding:'10px 0', fontSize:13, fontWeight:700, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:6, fontFamily:FONT, whiteSpace:'nowrap' }}>
          <Ic.cupon s={15}/> Agregar a cuponera
        </button>
        {/* Cajita de precios (igual al home) */}
        <div style={{ border:`1px solid ${LINE}`, borderRadius:10, overflow:'hidden', marginTop:10 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'8px 12px' }}>
            <span style={{ fontSize:10, fontWeight:700, letterSpacing:'0.07em', textTransform:'uppercase', color:MUTED }}>Ahorro</span>
            <span style={{ fontSize:13, fontWeight:800, color:GREEN }}>{fmt$(off)}</span>
          </div>
          <div style={{ height:1, background:LINE }}/>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'8px 12px' }}>
            <span style={{ fontSize:10, fontWeight:700, letterSpacing:'0.07em', textTransform:'uppercase', color:MUTED, whiteSpace:'nowrap' }}>Lo activás con</span>
            <span style={{ display:'inline-flex', alignItems:'center', gap:5, whiteSpace:'nowrap' }}><Coin size={15}/><span style={{ fontSize:13, fontWeight:800, color:INK }}>{cred} créditos</span></span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Card de Plan activo · versión clara (mensual grande, anual chico gris) ──
function PlanActivoLight() {
  return (
    <div style={{ background:CARD, border:`1px solid ${LINE}`, borderRadius:16, padding:20, fontFamily:FONT, height:'100%', boxSizing:'border-box', display:'flex', flexDirection:'column' }}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
        <div style={{ width:44, height:44, borderRadius:12, background:PS, color:P, display:'grid', placeItems:'center', flexShrink:0 }}><Ic.zap s={22}/></div>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:11, color:MUTED, fontWeight:700, textTransform:'uppercase', letterSpacing:'0.06em' }}>Plan activo</div>
          <div style={{ fontSize:20, fontWeight:800, color:INK }}>PLUS</div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ display:'flex', alignItems:'baseline', gap:5, justifyContent:'flex-end' }}>
            <span style={{ fontSize:26, fontWeight:800, color:INK, letterSpacing:'-0.02em' }}>$18.300</span>
            <span style={{ fontSize:13, color:MUTED, fontWeight:600 }}>/mes</span>
          </div>
          <div style={{ fontSize:12, color:MUTED, marginTop:2 }}>$220.000 /año</div>
        </div>
      </div>
      <div style={{ marginTop:'auto', background:BG, borderRadius:11, padding:'11px 14px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ fontSize:12.5, color:INK2 }}>Próximo cobro · 1 de julio</span>
        <span style={{ fontSize:12.5, fontWeight:700, color:P, display:'inline-flex', alignItems:'center', gap:4, cursor:'pointer' }}>Gestionar <Ic.chevR s={14}/></span>
      </div>
    </div>
  );
}

// ─── Card de Plan activo · versión oscura (para el Resumen) ────
function PlanActivo({ compact }) {
  return (
    <div style={{ background:`linear-gradient(135deg, ${NAVY} 0%, #1e293b 100%)`, borderRadius:16, padding: compact?18:22, fontFamily:FONT, color:'#fff' }}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
        <div style={{ width:42, height:42, borderRadius:12, background:P, display:'grid', placeItems:'center', flexShrink:0 }}><span style={{ color:'#fff' }}><Ic.zap s={22}/></span></div>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:11, color:'rgba(255,255,255,0.5)', fontWeight:700, textTransform:'uppercase', letterSpacing:'0.06em' }}>Plan activo</div>
          <div style={{ fontSize:20, fontWeight:800 }}>PLUS</div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ display:'flex', alignItems:'baseline', gap:5, justifyContent:'flex-end' }}>
            <span style={{ fontSize:24, fontWeight:800 }}>$18.300</span>
            <span style={{ fontSize:13, color:'rgba(255,255,255,0.55)', fontWeight:600 }}>/mes</span>
          </div>
          <div style={{ fontSize:12, color:'rgba(255,255,255,0.4)', marginTop:2 }}>$220.000 /año</div>
        </div>
      </div>
      <div style={{ background:'rgba(255,255,255,0.08)', borderRadius:11, padding:'11px 14px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ fontSize:12.5, color:'rgba(255,255,255,0.7)' }}>Próximo cobro · 1 de julio</span>
        <span style={{ fontSize:12.5, fontWeight:700, color:'#fff', display:'inline-flex', alignItems:'center', gap:4, cursor:'pointer' }}>Gestionar <Ic.chevR s={14}/></span>
      </div>
    </div>
  );
}

// ─── Movimientos (libro bimoneda) ─────────────────────────────
// kind: 'cred-in' | 'cred-out' | 'pesos'
const MOVS = [
  { kind:'cred-in',  title:'Huésped compró cuponera de Churros El Topo', date:'Hoy · 12:40', cred:+1 },
  { kind:'cred-in',  title:'Huésped compró cuponera de La Pescadería', date:'Hoy · 09:15', cred:+1 },
  { kind:'cred-out', title:'Canjeaste Pack −$2.000 de abono', date:'Ayer · 18:02', cred:-8, mon:'cred' },
  { kind:'pesos',    title:'Cobro plan PLUS · Junio', date:'1 jun', pesos:-18300 },
  { kind:'cred-out', title:'Enviaste créditos a Valentina R.', date:'29 may', cred:-5 },
  { kind:'cred-in',  title:'Huésped compró cuponera de Paseos en Cuatri', date:'28 may', cred:+1 },
  { kind:'pesos',    title:'Compra de 20 créditos', date:'27 may', pesos:-12100, cred:+20 },
];

function MovRow({ m, last }) {
  const cfg = m.kind==='cred-in'
    ? { ic:<Ic.inflow s={17}/>, bg:GREENS, fg:GREEN }
    : m.kind==='cred-out'
    ? { ic:<Ic.outflow s={17}/>, bg:'#fff4f4', fg:RED }
    : { ic:<Ic.card s={17}/>, bg:PS, fg:P };
  return (
    <div style={{ display:'flex', alignItems:'center', gap:13, padding:'13px 4px', borderBottom: last?'none':`1px solid ${BG}` }}>
      <div style={{ width:38, height:38, borderRadius:11, background:cfg.bg, display:'grid', placeItems:'center', color:cfg.fg, flexShrink:0 }}>{cfg.ic}</div>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:13.5, fontWeight:600, color:INK, lineHeight:1.3 }}>{m.title}</div>
        <div style={{ fontSize:11.5, color:MUTED, marginTop:2 }}>{m.date}</div>
      </div>
      <div style={{ textAlign:'right', flexShrink:0 }}>
        {m.cred != null && (
          <div style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:14, fontWeight:800, color: m.cred>0?GREEN:INK2 }}>
            {m.cred>0?'+':'−'}<Coin size={14}/>{Math.abs(m.cred)}
          </div>
        )}
        {m.pesos != null && (
          <div style={{ fontSize:14, fontWeight:800, color:INK, marginTop: m.cred!=null?2:0 }}>−{fmt$(m.pesos)}</div>
        )}
      </div>
    </div>
  );
}

function FiltroMoneda({ sel = 'todo' }) {
  const opts = [['todo','Todo'],['cred','Créditos'],['pesos','Pesos']];
  return (
    <div style={{ display:'flex', gap:6 }}>
      {opts.map(([id,label]) => (
        <span key={id} style={{
          display:'inline-flex', alignItems:'center', gap:5, padding:'5px 12px', borderRadius:999, fontSize:12, fontWeight:700, cursor:'pointer',
          background: sel===id?INK:'transparent', color: sel===id?'#fff':INK2, border:`1px solid ${sel===id?INK:LINE}`,
        }}>
          {id==='cred' && <Coin size={13}/>}{label}
        </span>
      ))}
    </div>
  );
}

function Movimientos({ filtro = 'todo', rows = MOVS }) {
  return (
    <div style={{ background:CARD, borderRadius:16, border:`1px solid ${LINE}`, padding:20, fontFamily:FONT }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8, flexWrap:'wrap', gap:10 }}>
        <div style={{ fontSize:15, fontWeight:800, color:INK }}>Movimientos</div>
        <FiltroMoneda sel={filtro}/>
      </div>
      <div>{rows.map((m,i) => <MovRow key={i} m={m} last={i===rows.length-1}/>)}</div>
    </div>
  );
}

// ─── Card de acción genérica (las 3 opciones) ─────────────────
function AccionCard({ icon, tint, title, desc, foot }) {
  return (
    <div style={{ background:CARD, borderRadius:16, border:`1px solid ${LINE}`, padding:18, fontFamily:FONT, display:'flex', flexDirection:'column', gap:12, cursor:'pointer', height:'100%', boxSizing:'border-box' }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div style={{ width:42, height:42, borderRadius:12, background:tint+'18', color:tint, display:'grid', placeItems:'center' }}>{icon}</div>
        <span style={{ color:MUTED }}><Ic.chevR/></span>
      </div>
      <div>
        <div style={{ fontSize:15, fontWeight:800, color:INK }}>{title}</div>
        <div style={{ fontSize:12.5, color:INK2, marginTop:4, lineHeight:1.45 }}>{desc}</div>
      </div>
      {foot && <div style={{ marginTop:'auto', paddingTop:10, borderTop:`1px solid ${BG}` }}>{foot}</div>}
    </div>
  );
}

Object.assign(window, {
  CK: { P, PD, PS, INK, INK2, MUTED, LINE, BG, CARD, NAVY, GREEN, GREENS, YELLOW, RED, FONT, fmt$ },
  Coin, Credits, GLogo, Ic, PackFicha, PlanActivo, PlanActivoLight, Movimientos, MovRow, FiltroMoneda, AccionCard, MOVS,
});
